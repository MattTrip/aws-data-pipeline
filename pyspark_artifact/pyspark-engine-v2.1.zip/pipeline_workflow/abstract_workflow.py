from abc import abstractmethod, ABC

class AbstractWorkflow(ABC):
    def __init__(self, params, spark):
        self.params = params
        self.spark = spark
        self.input_step = {
            'csv' : 'pipeline_read_csv',
            'json' : 'pipeline_read_json',
            'parquet' : 'pipeline_read_parquet',
        }
        self.transform_step = 'pipeline_transform'
        self.output_step = {
            'csv' : 'pipeline_save_csv',
            'json' : 'pipeline_save_json',
            'parquet' : 'pipeline_save_parquet',
        }

    @abstractmethod
    def run(self):
        pass

    # according to input and output file types, load the appropriate steps for processing
    def get_config(self, input_file_type, output_file_type):
        step_list = []
        step_list.append( self.input_step[input_file_type] )      # 1st element: input step
        step_list.append( self.transform_step )                   # 2nd element: transform step
        step_list.append( self.output_step[output_file_type] )    # 3rd element: save step
        return step_list

