from pipeline_workflow.abstract_workflow import AbstractWorkflow
from pipeline_step.pipeline_step_loader import PipelineStepLoader
import pipeline_custom
import pkgutil



class DefaultWorkflow(AbstractWorkflow):
    def __init__(self, params, spark):
        super().__init__(params, spark)
        self.params = params
        self.spark = spark

    # this function takes the file type parameters and runs the appropriate read/transform/save classes
    def run(self):
        print('+++++++++ VALIDATING self.params.args var: ' + str(self.params.args))
        input_file_type = self.params.args['input_file_type']
        output_file_type = self.params.args['output_file_type']
        print(f'+++++++++  input file type var : {input_file_type}' )
        print(f'+++++++++ output file type var : {output_file_type}' )
        steps = super().get_config(input_file_type, output_file_type)
        print('+++++++++ config- steps var = ' + str(steps))
        # step 1 - read the file as dataframe
        df = None
        for node in steps:
            custom_steps = set(
                [modname for importer, modname, ispkg in pkgutil.iter_modules(pipeline_custom.__path__)])
            print('+++++++++ custom_steps = ', custom_steps)
            temp_cls, params = PipelineStepLoader.get_class(node, self.params, custom_steps=custom_steps)
            print(f'+++++++++ temp_cls={temp_cls}   params={params}')

            df = temp_cls.run(self.spark, params, df)