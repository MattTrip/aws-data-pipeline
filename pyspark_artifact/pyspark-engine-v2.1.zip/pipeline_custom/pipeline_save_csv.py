from pyspark.sql import functions as f
from pipeline_step.pipeline_step import PipelineStep

# class to write the dataframe csv file format
# for faster future processing, the data is partitioned according to
# the (runtime parameter)-specified column 

class PipelineSaveCsv(PipelineStep):
    def __init__(self):
        super().__init__()
        print('============>: Save CSV data')

    def run(self, spark, params, df):
        output_path = params.args['output_path']
        partition_column = params.args['partition_column']
        df.write.option('header','true').partitionBy(partition_column).csv(output_path)
        return df 
