from pipeline_step.pipeline_step import PipelineStep

# class to read in json file (to dataframe)

class PipelineReadJson(PipelineStep):
    def __init__(self):
        super().__init__()
        print('============>: Read JSON File')

    def run(self, spark, params, df):
        path = params.args['input_path']
        #spark.read.json(path).show()
        spark.read.json(path).show()
        return spark.read.json(path) # spark.read.option('header','true').option("multiline", "true").json(path)