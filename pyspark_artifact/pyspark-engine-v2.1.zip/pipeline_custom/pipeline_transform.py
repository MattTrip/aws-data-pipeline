from pyspark.sql import functions as f
from pipeline_step.pipeline_step import PipelineStep
from pyspark.sql.functions import col

# class to perform transformation of the data
# this depends on business requirements and schema
# for now, just a trivial transformation is done by adding a column

class PipelineTransform(PipelineStep):
    def __init__(self):
        super().__init__()
        print('============> Transforming data')

    def run(self, spark, params, df):
        df = df.withColumn('author', f.lit('wcd-albert'))
        return df